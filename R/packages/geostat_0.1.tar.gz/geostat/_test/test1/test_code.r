rm(list=ls())

setwd("/home/dkneis/progress/echse_tools/geostat/R/test")
source("../geostat.r")

ifile_obs= "obs.txt"
ifile_loc= "loc.txt"

ofile_resid= "resid.txt"
ofile_coeff= "coeff.txt"

residualTimeSeries(
  file_obs= ifile_obs,
  file_loc= ifile_loc,
  colsep="\t",
  obs_colTime="datetime",
  loc_colId="id",
  loc_colPred="z",
  r2min= 0.36,
  file_resid= ofile_resid,
  file_coeff= ofile_coeff,
  ndigits=6,
  overwrite=TRUE
)




