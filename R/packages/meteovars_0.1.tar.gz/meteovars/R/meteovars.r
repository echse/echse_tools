
#' Estimation / conversion of meteorological variables
#'
#' Type \code{help(package="meteovars")} to inspect the package description.
#'
#' @name meteovars-package
#' @aliases meteovars
#' @docType package
{invisible(NULL)}

